﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace task_3_build_assesment
{
    public partial class textCode : Form
    {
        public textCode()
        {
            InitializeComponent();
            
            string indent = "";
            string[] codelines = code.block_code.Split('\n');
            string[] textboxlines = {};
            foreach (string line in codelines)
            {
                if (line.Contains("}") && indent.Length >= 2)
                {
                    indent.Remove(0,2);
                }
                textboxlines.Append(string.Format("{0}{1}", indent, line));
                if (code.block_code.Contains("{"))
                {
                    indent += "  ";
                }
            }
           // textBox1.Text = string.Join("\n", textboxlines);
            textBox1.Text = code.block_code;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Owner.Show();
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            label1.Text = textBox1.Text;
           /* string[] fullcode = textBox1.Text.Split('\n');
            label1.Text = "";
            foreach (string text in fullcode)
            {
                label1.Text = string.Format("{0} {1}", label1.Text, text);
            }*/
        }
    }
}