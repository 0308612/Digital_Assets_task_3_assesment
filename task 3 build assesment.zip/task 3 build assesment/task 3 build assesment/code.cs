﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace task_3_build_assesment
{
    public partial class code : Form
    {
        PictureBox[] pictures = new PictureBox[7];
        List<string> blocks = new List<string>();
        public static string block_code;
        public code()
        {
            InitializeComponent();

            for (int i = 0; i < pictures.Length; i++)
            {
                pictures[i] = new PictureBox();
                pictures[i].SizeMode = PictureBoxSizeMode.StretchImage;
                pictures[i].AllowDrop = true;
                pictures[i].DragEnter += new DragEventHandler(pictures_DragEnter);
                pictures[i].DragDrop += new DragEventHandler(pictures_DragDrop);
                tblCodearea.Controls.Add(pictures[i]);
            }
        }

        private void codeBlock_MouseDown(object sender, MouseEventArgs e)
        {
            PictureBox codeBlock = sender as PictureBox;

            DataObject dragImage = new DataObject();
            dragImage.SetData(DataFormats.Bitmap, true, codeBlock.Image);
            dragImage.SetData(DataFormats.Text, true, codeBlock.Tag);

            DoDragDrop(dragImage, DragDropEffects.Copy);
        }
        
        private void pictures_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = e.AllowedEffect;
        }

        private void pictures_DragDrop(object sender, DragEventArgs e)
        {
            PictureBox picture = sender as PictureBox;

            picture.Image = (Bitmap)e.Data.GetData(DataFormats.Bitmap);
            picture.Tag = e.Data.GetData(TextDataFormat.Text.ToString());

            lblOut.Text = "";
            blocks.Clear();

            for (int i = 0; i < 7; i++)
            {
                blocks.Add(string.Format("{0}", pictures[i].Tag));
                if (blocks[i].Contains("if"))
                {
                    lblOut.Text += "if ( ) {\r\n";
                }
                else if (blocks[i].Contains("for"))
                {
                    lblOut.Text += "for ( , , ) {\r\n";
                }
                else if (blocks[i].Contains("while"))
                {
                    lblOut.Text += "while ( ) {\r\n";
                }
                else if (blocks[i].Contains("print"))
                {
                    lblOut.Text += "Console.WriteLine ( )\r\n";
                }
                else if (blocks[i].Contains("}"))
                {
                    lblOut.Text += "}\r\n";
                }
                block_code = lblOut.Text;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Owner.Show();
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textCode f1 = new textCode();
            f1.Owner = this;
            f1.StartPosition = FormStartPosition.Manual;
            f1.Location = this.Location;
            f1.Show();
            this.Hide();
        }
    }
}
